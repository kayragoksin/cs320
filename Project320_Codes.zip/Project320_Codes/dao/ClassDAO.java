package dao;

import model.Class;
import utils.DataSource;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClassDAO {
    public List<Class> findAll() throws SQLException {
        String sql = "SELECT class_id, time, instructor_id, capacity FROM Class";
        try (Connection conn = DataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            List<Class> list = new ArrayList<>();
            while (rs.next()) {
                Class cls = new Class();
                cls.setClassId(rs.getInt("class_id"));
                Timestamp ts = rs.getTimestamp("time");
                cls.setTime(ts.toLocalDateTime());
                cls.setInstructorId(rs.getInt("instructor_id"));
                cls.setCapacity(rs.getInt("capacity"));
                list.add(cls);
            }
            return list;
        }
    }
}
