package gui;

import javax.swing.*;
import java.awt.*;

/**
 * Главное окно приложения «Gym Management».
 */
public class MainFrame extends JFrame {

    public MainFrame() {
        super("Gym Management");
        // Закрытие приложения по нажатию на крестик
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // Используем BorderLayout для размещения компонентов
        setLayout(new BorderLayout());

        // Создаём табы
        JTabbedPane tabs = new JTabbedPane();
        // Вкладка со списком членов клуба
        tabs.addTab("Members", new MemberPanel());
        // Вкладка с расписанием классов
        tabs.addTab("Classes", new ClassPanel());

        // Добавляем табы в центр окна
        add(tabs, BorderLayout.CENTER);

        // Задаём размер окна
        setSize(800, 600);
        // Центрируем окно на экране
        setLocationRelativeTo(null);
        // Делаем окно видимым
        setVisible(true);
    }
}
