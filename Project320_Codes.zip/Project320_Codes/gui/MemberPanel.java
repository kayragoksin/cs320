package gui;

import dao.MemberDAO;
import model.Member;
import gui.MemberPanel;
import gui.ClassPanel;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class MemberPanel extends JPanel {
    private final MemberTableModel model = new MemberTableModel();

    public MemberPanel() {
        setLayout(new BorderLayout());
        JTable table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);
        loadMembers();
    }

    private void loadMembers() {
        try {
            List<Member> list = new MemberDAO().findAll();
            model.setMembers(list);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Ошибка загрузки членов клуба:\n" + e.getMessage(),
                    "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
